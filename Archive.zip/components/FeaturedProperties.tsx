'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { MapPin, Bed, Bath, Maximize, ShieldCheck, Sparkles, ArrowRight, TrendingUp } from 'lucide-react';
import { propertyService } from '@/lib/services';
import type { Property } from '@/lib/types';
import { useTheme } from '@/hooks/use-theme';

const BADGE_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  'New Launch':    { bg: 'rgba(59,130,246,0.10)', text: '#3b82f6', border: 'rgba(59,130,246,0.25)' },
  'Hot Deal':      { bg: 'rgba(239,68,68,0.10)',  text: '#ef4444', border: 'rgba(239,68,68,0.25)'  },
  'Ready to Move': { bg: 'rgba(16,185,129,0.10)', text: '#10b981', border: 'rgba(16,185,129,0.25)' },
  'Premium':       { bg: 'rgba(139,92,246,0.10)', text: '#8b5cf6', border: 'rgba(139,92,246,0.25)' },
};

const FILTERS = ['All', 'sale', 'rent'];

// Scroll-reveal hook
function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.07 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function PropertyCard({ property, theme, idx }: { property: Property; theme: ReturnType<typeof useTheme>; idx: number }) {
  const { accent, accentFg, a } = theme;
  const primaryImage = property.images?.find((img: any) => img.isPrimary)?.url
    || property.images?.[0]?.url || null;
  const badge = property.badge ? BADGE_COLORS[property.badge] : null;
  const { ref, visible } = useReveal();

  return (
    <div
      ref={ref}
      style={{
        opacity:    visible ? 1 : 0,
        transform:  visible ? 'translateY(0) scale(1)' : 'translateY(32px) scale(0.97)',
        transition: `opacity 0.6s cubic-bezier(0.22,1,0.36,1) ${idx * 0.1}s, transform 0.6s cubic-bezier(0.22,1,0.36,1) ${idx * 0.1}s`,
      }}
    >
      <Link href={`/properties/${property.slug}`} className="block group">
        <div
          className="rounded-2xl overflow-hidden border"
          style={{
            background:   'var(--card)',
            borderColor:  'var(--border)',
            transition:   'border-color 0.3s ease, transform 0.3s cubic-bezier(0.22,1,0.36,1), box-shadow 0.3s ease',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLElement).style.borderColor = `${accent}50`;
            (e.currentTarget as HTMLElement).style.transform = 'translateY(-6px)';
            (e.currentTarget as HTMLElement).style.boxShadow = `0 20px 40px ${a(0.10)}`;
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)';
            (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
            (e.currentTarget as HTMLElement).style.boxShadow = 'none';
          }}
        >
          {/* Image */}
          <div className="relative h-52 overflow-hidden" style={{ background: 'var(--surface-2,#f1f5f9)' }}>
            {primaryImage ? (
              <img
                src={primaryImage}
                alt={property.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-107"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: `${accent}08` }}>
                <Sparkles size={40} style={{ color: `${accent}40` }} />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

            {/* Badges */}
            <div className="absolute top-3 left-3 flex gap-1.5">
              {property.badge && badge && (
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full border backdrop-blur-sm"
                  style={{ background: badge.bg, color: badge.text, borderColor: badge.border }}>
                  {property.badge}
                </span>
              )}
              {property.isReraRegistered && (
                <span className="text-xs font-semibold px-2 py-1 rounded-full border flex items-center gap-1 backdrop-blur-sm"
                  style={{ background: 'rgba(16,185,129,0.15)', color: '#10b981', borderColor: 'rgba(16,185,129,0.3)' }}>
                  <ShieldCheck size={9} /> RERA
                </span>
              )}
            </div>

            {/* AI Match */}
            {property.aiMatch && (
              <div className="absolute top-3 right-3 backdrop-blur-sm rounded-full px-2.5 py-1 flex items-center gap-1 border"
                style={{ background: `${accent}22`, borderColor: `${accent}40` }}>
                <Sparkles size={10} style={{ color: accent }} />
                <span className="text-xs font-bold" style={{ color: accent }}>{property.aiMatch}%</span>
              </div>
            )}

            {/* Price on image */}
            <div className="absolute bottom-3 left-3">
              <span className="text-white font-bold text-lg drop-shadow-lg">
                ₹{property.priceLabel || property.price}
              </span>
            </div>
          </div>

          {/* Content */}
          <div className="p-4">
            <h3
              className="font-semibold text-sm leading-tight mb-1.5 line-clamp-1 transition-colors"
              style={{ color: 'var(--foreground)' }}
            >
              {property.title}
            </h3>
            <div className="flex items-center gap-1 text-xs mb-3" style={{ color: 'var(--text-muted)' }}>
              <MapPin size={10} style={{ color: accent }} />
              <span>{property.locality}{property.locality && property.city ? ', ' : ''}{property.city}</span>
            </div>

            <div className="flex items-center gap-3 text-xs border-t pt-3" style={{ borderColor: 'var(--border)', color: 'var(--text-muted)' }}>
              {property.configuration && (
                <span className="font-semibold" style={{ color: 'var(--foreground)' }}>{property.configuration}</span>
              )}
              {property.bedrooms && <span className="flex items-center gap-0.5"><Bed size={10} /> {property.bedrooms}</span>}
              {property.bathrooms && <span className="flex items-center gap-0.5"><Bath size={10} /> {property.bathrooms}</span>}
              {property.area && <span className="flex items-center gap-0.5"><Maximize size={10} /> {property.area}sqft</span>}
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}

export default function FeaturedProperties() {
  const theme = useTheme();
  const { accent, accentFg, a } = theme;
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('All');
  const { ref: headerRef, visible: headerVisible } = useReveal();

  useEffect(() => {
    propertyService.getAll({ limit: 6 })
      .then(res => setProperties(res.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const filtered = activeFilter === 'All'
    ? properties
    : properties.filter(p => p.listingType?.toLowerCase() === activeFilter.toLowerCase());

  return (
    <section className="py-16" id="featured" style={{ background: 'var(--background)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div
          ref={headerRef}
          className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4"
          style={{
            opacity:   headerVisible ? 1 : 0,
            transform: headerVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.6s ease, transform 0.6s ease',
          }}
        >
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${accent}14` }}>
                <Sparkles size={13} style={{ color: accent }} />
              </div>
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: accent }}>AI Curated</span>
            </div>
            <h2 className="text-3xl font-bold mb-1" style={{ color: 'var(--foreground)' }}>Featured Properties</h2>
            <p className="text-sm flex items-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
              <TrendingUp size={13} style={{ color: accent }} />
              Handpicked by our AI based on market trends
            </p>
          </div>

          {/* Filter pills */}
          <div className="flex gap-2">
            {FILTERS.map(f => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className="px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 border capitalize"
                style={activeFilter === f
                  ? { backgroundColor: accent, color: accentFg, borderColor: accent }
                  : { background: 'transparent', color: 'var(--text-muted)', borderColor: 'var(--border)' }
                }
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded-2xl overflow-hidden border" style={{ borderColor: 'var(--border)', background: 'var(--card)' }}>
                <div className="h-52 skeleton" />
                <div className="p-4 space-y-3">
                  <div className="h-4 skeleton w-3/4" />
                  <div className="h-3 skeleton w-1/2" />
                  <div className="h-3 skeleton w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
            <Sparkles size={32} className="mx-auto mb-3 opacity-30" style={{ color: accent }} />
            <p>No properties found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((p, i) => (
              <PropertyCard key={(p as any)._id || p.id} property={p} theme={theme} idx={i} />
            ))}
          </div>
        )}

        {/* CTA */}
        <div
          className="text-center mt-10"
          style={{
            opacity: !loading ? 1 : 0,
            transition: 'opacity 0.6s ease 0.5s',
          }}
        >
          <Link
            href="/properties"
            className="inline-flex items-center gap-2 border px-6 py-3 rounded-full font-medium transition-all duration-200 text-sm"
            style={{ borderColor: `${accent}40`, color: accent }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = `${accent}0e`; (e.currentTarget as HTMLElement).style.borderColor = accent; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.borderColor = `${accent}40`; }}
          >
            View All Properties <ArrowRight size={15} />
          </Link>
        </div>
      </div>
    </section>
  );
}